using Contrast.Core;
using Contrast.Data;
using Contrast.Level;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Contrast.UI
{
    /// <summary>
    /// Runtime editor UI: import/export, selected platform data, trajectory
    /// editing, platform deletion and palette.
    /// </summary>
    public sealed class LevelEditorUI : MonoBehaviour
    {
        private GameObject root;
        private Text statusText;
        private InputField posX;
        private InputField posY;
        private InputField sizeX;
        private InputField sizeY;
        private InputField color;
        private bool suppressFields;
        private ColorPlatform selectedPlatform;
        private LevelEditorController controller;

        // ── Delete button ──────────────────────────────────────────
        private Button deleteButton;

        // ── Trajectory controls ────────────────────────────────────
        private GameObject trajSection;
        private Toggle     trajEnabled;
        private Dropdown   trajCurveType;
        private Dropdown   trajDomainMode;
        private Dropdown   trajPlaybackMode;
        private InputField trajOriginX;
        private InputField trajOriginY;
        private InputField trajRotation;
        private InputField trajScaleX;
        private InputField trajParamMin;
        private InputField trajParamMax;
        private InputField trajRadius;
        private InputField trajDuration;
        private Toggle     trajReverse;

        // Spatial bounds fields (Line + SpatialBounds only)
        private GameObject boundsGroup;
        private InputField trajBoundsXMin;
        private InputField trajBoundsXMax;
        private InputField trajBoundsYMin;
        private InputField trajBoundsYMax;

        // Labels to show/hide per curve type
        private GameObject radiusGroup;
        private GameObject rotationGroup;
        private Text       trajValidation;

        private bool suppressTraj;

        public void Show(bool visible)
        {
            if (root == null)
                BuildUI();
            root.SetActive(visible);
        }

        public void SetSelectedPlatform(ColorPlatform platform)
        {
            selectedPlatform = platform;
            if (platform == null)
            {
                ClearSelectedPlatform();
                return;
            }

            suppressFields = true;
            posX.text = platform.Position.x.ToString("F3");
            posY.text = platform.Position.y.ToString("F3");
            sizeX.text = platform.Size.x.ToString("F3");
            sizeY.text = platform.Size.y.ToString("F3");
            color.text = platform.RawGrayscaleColor.ToString("F1");
            suppressFields = false;

            if (deleteButton != null)
                deleteButton.interactable = true;

            RefreshTrajectoryUI(platform);
        }

        public void RefreshSelectedPlatform(ColorPlatform platform)
        {
            if (selectedPlatform == platform)
                SetSelectedPlatform(platform);
        }

        public void ClearSelectedPlatform()
        {
            selectedPlatform = null;
            if (posX == null)
                return;
            suppressFields = true;
            posX.text = string.Empty;
            posY.text = string.Empty;
            sizeX.text = string.Empty;
            sizeY.text = string.Empty;
            color.text = string.Empty;
            suppressFields = false;

            if (deleteButton != null)
                deleteButton.interactable = false;

            ClearTrajectoryUI();
        }

        public void SetStatus(string message)
        {
            if (statusText != null)
                statusText.text = message;
            Debug.Log("[LEVEL_EDITOR] " + message);
        }

        private void BuildUI()
        {
            controller = FindAnyObjectByType<LevelEditorController>();
            EnsureEventSystem();

            GameObject canvasGo = NewUI("Canvas", transform);
            Canvas canvas = canvasGo.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            canvas.sortingOrder = 500;
            CanvasScaler scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            canvasGo.AddComponent<GraphicRaycaster>();

            root = NewUI("EditorRoot", canvasGo.transform);
            Stretch(root.GetComponent<RectTransform>());

            GameObject top = NewUI("TopBar", root.transform);
            Image topImage = top.AddComponent<Image>();
            topImage.color = new UnityEngine.Color(0f, 0f, 0f, 0.78f);
            RectTransform topRt = top.GetComponent<RectTransform>();
            topRt.anchorMin = new Vector2(0f, 1f);
            topRt.anchorMax = new Vector2(1f, 1f);
            topRt.pivot = new Vector2(0.5f, 1f);
            topRt.sizeDelta = new Vector2(0f, 76f);
            topRt.anchoredPosition = Vector2.zero;

            CreateButton(top.transform, "IMPORT", new Vector2(100f, -38f), () => controller?.RequestImport());
            CreateButton(top.transform, "EXPORT", new Vector2(250f, -38f), () => controller?.RequestExport());
            CreateButton(top.transform, "BACK", new Vector2(400f, -38f), () => GameManager.Instance?.ReturnToMainMenu());

            GameObject status = NewUI("Status", top.transform);
            statusText = status.AddComponent<Text>();
            statusText.font = GetFont();
            statusText.fontSize = 24;
            statusText.alignment = TextAnchor.MiddleLeft;
            statusText.color = UnityEngine.Color.white;
            RectTransform statusRt = status.GetComponent<RectTransform>();
            statusRt.anchorMin = new Vector2(0f, 0.5f);
            statusRt.anchorMax = new Vector2(0f, 0.5f);
            statusRt.pivot = new Vector2(0f, 0.5f);
            statusRt.sizeDelta = new Vector2(900f, 40f);
            statusRt.anchoredPosition = new Vector2(520f, 0f);

            BuildInspector(root.transform);
            BuildPalette(root.transform);

            root.SetActive(false);
        }

        private void BuildInspector(Transform parent)
        {
            // Scrollable inspector panel
            GameObject panel = NewUI("Inspector", parent);
            Image bg = panel.AddComponent<Image>();
            bg.color = new UnityEngine.Color(0.05f, 0.05f, 0.05f, 0.82f);
            RectTransform rt = panel.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 0.5f);
            rt.sizeDelta = new Vector2(350f, -76f);
            rt.anchoredPosition = new Vector2(0f, -38f);

            // Add scroll view inside the inspector panel
            GameObject scrollViewGo = NewUI("ScrollView", panel.transform);
            ScrollRect scrollRect = scrollViewGo.AddComponent<ScrollRect>();
            scrollRect.horizontal = false;
            scrollRect.vertical = true;
            scrollRect.scrollSensitivity = 30f;
            Image scrollBg = scrollViewGo.AddComponent<Image>();
            scrollBg.color = new UnityEngine.Color(0f, 0f, 0f, 0f); // transparent but raycastable
            RectTransform scrollRt = scrollViewGo.GetComponent<RectTransform>();
            Stretch(scrollRt);

            // Viewport (mask)
            GameObject viewport = NewUI("Viewport", scrollViewGo.transform);
            viewport.AddComponent<Image>().color = new UnityEngine.Color(0, 0, 0, 0);
            viewport.AddComponent<Mask>().showMaskGraphic = false;
            RectTransform viewportRt = viewport.GetComponent<RectTransform>();
            Stretch(viewportRt);

            // Content container
            GameObject content = NewUI("Content", viewport.transform);
            RectTransform contentRt = content.GetComponent<RectTransform>();
            contentRt.anchorMin = new Vector2(0f, 1f);
            contentRt.anchorMax = new Vector2(1f, 1f);
            contentRt.pivot = new Vector2(0.5f, 1f);
            // Height will be set after adding all elements
            contentRt.sizeDelta = new Vector2(0f, 1400f); // enough for all controls

            scrollRect.viewport = viewportRt;
            scrollRect.content = contentRt;

            // === Platform properties section ===
            CreateLabel(content.transform, "PLATFORM", new Vector2(22f, -30f), 34);
            posX = CreateField(content.transform, "Position X", -100f);
            posY = CreateField(content.transform, "Position Y", -160f);
            sizeX = CreateField(content.transform, "Size X", -220f);
            sizeY = CreateField(content.transform, "Size Y", -280f);
            color = CreateField(content.transform, "Color 0..255", -340f);

            AddFieldCallback(posX);
            AddFieldCallback(posY);
            AddFieldCallback(sizeX);
            AddFieldCallback(sizeY);
            AddFieldCallback(color);

            // === Delete button ===
            float deleteY = -410f;
            deleteButton = CreateColoredButton(
                content.transform,
                "DELETE PLATFORM",
                new Vector2(22f, deleteY),
                new Vector2(300f, 48f),
                new UnityEngine.Color(0.8f, 0.15f, 0.15f, 1f),
                () => controller?.DeleteSelectedPlatform());
            deleteButton.interactable = false;

            // === Trajectory section ===
            float trajStartY = -480f;
            CreateLabel(content.transform, "TRAJECTORY", new Vector2(22f, trajStartY), 30);
            trajSection = NewUI("TrajSection", content.transform);
            RectTransform trajRt = trajSection.GetComponent<RectTransform>();
            trajRt.anchorMin = new Vector2(0f, 1f);
            trajRt.anchorMax = new Vector2(1f, 1f);
            trajRt.pivot = new Vector2(0f, 1f);
            trajRt.anchoredPosition = new Vector2(0f, trajStartY - 40f);
            trajRt.sizeDelta = new Vector2(0f, 800f);

            float y = 0f;

            // Enabled toggle
            trajEnabled = CreateToggle(trajSection.transform, "Enabled", ref y);
            trajEnabled.onValueChanged.AddListener(_ => ApplyTrajectory());

            // Curve type dropdown
            y -= 50f;
            trajCurveType = CreateDropdown(trajSection.transform, "Curve Type",
                new string[] { "Line", "Circle" }, ref y);
            trajCurveType.onValueChanged.AddListener(_ =>
            {
                UpdateTrajectoryVisibility();
                ApplyTrajectory();
            });

            // Domain mode dropdown
            y -= 50f;
            trajDomainMode = CreateDropdown(trajSection.transform, "Domain Mode",
                new string[] { "ParameterRange", "SpatialBounds" }, ref y);
            trajDomainMode.onValueChanged.AddListener(_ =>
            {
                UpdateTrajectoryVisibility();
                ApplyTrajectory();
            });

            // Playback mode dropdown
            y -= 50f;
            trajPlaybackMode = CreateDropdown(trajSection.transform, "Playback",
                new string[] { "Loop", "PingPong", "Once" }, ref y);
            trajPlaybackMode.onValueChanged.AddListener(_ => ApplyTrajectory());

            // Origin
            y -= 50f;
            trajOriginX = CreateTrajField(trajSection.transform, "Origin X", ref y);
            y -= 50f;
            trajOriginY = CreateTrajField(trajSection.transform, "Origin Y", ref y);

            // Rotation (Line only)
            y -= 50f;
            rotationGroup = NewUI("RotationGroup", trajSection.transform);
            RectTransform rotGrpRt = rotationGroup.GetComponent<RectTransform>();
            rotGrpRt.anchorMin = new Vector2(0f, 1f);
            rotGrpRt.anchorMax = new Vector2(1f, 1f);
            rotGrpRt.pivot = new Vector2(0f, 1f);
            rotGrpRt.anchoredPosition = new Vector2(0f, y);
            rotGrpRt.sizeDelta = new Vector2(0f, 50f);
            float localY = 0f;
            trajRotation = CreateTrajField(rotationGroup.transform, "Rotation°", ref localY);

            // Scale (Line only)
            y -= 50f;
            trajScaleX = CreateTrajField(trajSection.transform, "Scale/Length", ref y);

            // Param min/max
            y -= 50f;
            trajParamMin = CreateTrajField(trajSection.transform, "Param Min", ref y);
            y -= 50f;
            trajParamMax = CreateTrajField(trajSection.transform, "Param Max", ref y);

            // Radius (Circle only)
            y -= 50f;
            radiusGroup = NewUI("RadiusGroup", trajSection.transform);
            RectTransform radGrpRt = radiusGroup.GetComponent<RectTransform>();
            radGrpRt.anchorMin = new Vector2(0f, 1f);
            radGrpRt.anchorMax = new Vector2(1f, 1f);
            radGrpRt.pivot = new Vector2(0f, 1f);
            radGrpRt.anchoredPosition = new Vector2(0f, y);
            radGrpRt.sizeDelta = new Vector2(0f, 50f);
            localY = 0f;
            trajRadius = CreateTrajField(radiusGroup.transform, "Radius", ref localY);

            // Spatial bounds (Line + SpatialBounds only)
            y -= 50f;
            boundsGroup = NewUI("BoundsGroup", trajSection.transform);
            RectTransform bndsRt = boundsGroup.GetComponent<RectTransform>();
            bndsRt.anchorMin = new Vector2(0f, 1f);
            bndsRt.anchorMax = new Vector2(1f, 1f);
            bndsRt.pivot = new Vector2(0f, 1f);
            bndsRt.anchoredPosition = new Vector2(0f, y);
            bndsRt.sizeDelta = new Vector2(0f, 220f);
            localY = 0f;
            trajBoundsXMin = CreateTrajField(boundsGroup.transform, "Bounds X Min", ref localY);
            localY -= 50f;
            trajBoundsXMax = CreateTrajField(boundsGroup.transform, "Bounds X Max", ref localY);
            localY -= 50f;
            trajBoundsYMin = CreateTrajField(boundsGroup.transform, "Bounds Y Min", ref localY);
            localY -= 50f;
            trajBoundsYMax = CreateTrajField(boundsGroup.transform, "Bounds Y Max", ref localY);

            // Duration
            y -= 250f; // skip bounds group height
            trajDuration = CreateTrajField(trajSection.transform, "Duration (s)", ref y);

            // Reverse toggle
            y -= 50f;
            trajReverse = CreateToggle(trajSection.transform, "Reverse Dir", ref y);
            trajReverse.onValueChanged.AddListener(_ => ApplyTrajectory());

            // Validation text
            y -= 40f;
            GameObject valGo = NewUI("TrajValidation", trajSection.transform);
            trajValidation = valGo.AddComponent<Text>();
            trajValidation.font = GetFont();
            trajValidation.fontSize = 18;
            trajValidation.color = new UnityEngine.Color(1f, 0.3f, 0.3f, 1f);
            trajValidation.alignment = TextAnchor.UpperLeft;
            RectTransform valRt = valGo.GetComponent<RectTransform>();
            valRt.anchorMin = new Vector2(0f, 1f);
            valRt.anchorMax = new Vector2(0f, 1f);
            valRt.pivot = new Vector2(0f, 1f);
            valRt.sizeDelta = new Vector2(320f, 60f);
            valRt.anchoredPosition = new Vector2(22f, y);

            ClearTrajectoryUI();
        }

        private void BuildPalette(Transform parent)
        {
            GameObject panel = NewUI("Palette", parent);
            Image bg = panel.AddComponent<Image>();
            bg.color = new UnityEngine.Color(0.05f, 0.05f, 0.05f, 0.82f);
            RectTransform rt = panel.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(1f, 0f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 0.5f);
            rt.sizeDelta = new Vector2(320f, -76f);
            rt.anchoredPosition = new Vector2(0f, -38f);

            CreateLabel(panel.transform, "PALETTE", new Vector2(-22f, -75f), 34, TextAnchor.MiddleRight);
            CreatePaletteButton(panel.transform, "PLATFORM", LevelMarkerType.End, false, -160f);
            CreatePaletteButton(panel.transform, "START POS", LevelMarkerType.StartPos, true, -235f);
            CreatePaletteButton(panel.transform, "CHECKPOINT", LevelMarkerType.CheckPoint, true, -310f);
            CreatePaletteButton(panel.transform, "END", LevelMarkerType.End, true, -385f);
        }

        // ── Trajectory UI helpers ──────────────────────────────────

        private void RefreshTrajectoryUI(ColorPlatform platform)
        {
            if (trajSection == null)
                return;

            trajSection.SetActive(true);

            Trajectory traj = platform.GetTrajectory();
            TrajectoryData cfg = traj?.Config;

            suppressTraj = true;

            if (cfg == null)
            {
                trajEnabled.isOn = false;
                SetTrajectoryFieldsInteractable(false);
                suppressTraj = false;
                return;
            }

            trajEnabled.isOn = cfg.enabled;
            trajCurveType.value = (int)cfg.curveType;
            trajDomainMode.value = (int)cfg.domainMode;
            trajPlaybackMode.value = (int)cfg.playbackMode;
            trajOriginX.text = cfg.originX.ToString("F3");
            trajOriginY.text = cfg.originY.ToString("F3");
            trajRotation.text = cfg.rotation.ToString("F1");
            trajScaleX.text = cfg.scaleX.ToString("F2");
            trajParamMin.text = cfg.paramMin.ToString("F2");
            trajParamMax.text = cfg.paramMax.ToString("F2");
            trajRadius.text = cfg.radius.ToString("F2");
            trajDuration.text = cfg.duration.ToString("F2");
            trajReverse.isOn = cfg.reverseDirection;

            trajBoundsXMin.text = cfg.boundsXMin.ToString("F1");
            trajBoundsXMax.text = cfg.boundsXMax.ToString("F1");
            trajBoundsYMin.text = cfg.boundsYMin.ToString("F1");
            trajBoundsYMax.text = cfg.boundsYMax.ToString("F1");

            string error = Trajectory.Validate(cfg);
            if (trajValidation != null)
                trajValidation.text = error ?? "";

            SetTrajectoryFieldsInteractable(cfg.enabled);
            suppressTraj = false;

            UpdateTrajectoryVisibility();
        }

        private void ClearTrajectoryUI()
        {
            if (trajSection == null)
                return;

            suppressTraj = true;
            trajEnabled.isOn = false;
            trajSection.SetActive(false);
            if (trajValidation != null)
                trajValidation.text = "";
            suppressTraj = false;
        }

        private void SetTrajectoryFieldsInteractable(bool interactable)
        {
            if (trajCurveType != null) trajCurveType.interactable = interactable;
            if (trajDomainMode != null) trajDomainMode.interactable = interactable;
            if (trajPlaybackMode != null) trajPlaybackMode.interactable = interactable;
            if (trajOriginX != null) trajOriginX.interactable = interactable;
            if (trajOriginY != null) trajOriginY.interactable = interactable;
            if (trajRotation != null) trajRotation.interactable = interactable;
            if (trajScaleX != null) trajScaleX.interactable = interactable;
            if (trajParamMin != null) trajParamMin.interactable = interactable;
            if (trajParamMax != null) trajParamMax.interactable = interactable;
            if (trajRadius != null) trajRadius.interactable = interactable;
            if (trajDuration != null) trajDuration.interactable = interactable;
            if (trajReverse != null) trajReverse.interactable = interactable;
            if (trajBoundsXMin != null) trajBoundsXMin.interactable = interactable;
            if (trajBoundsXMax != null) trajBoundsXMax.interactable = interactable;
            if (trajBoundsYMin != null) trajBoundsYMin.interactable = interactable;
            if (trajBoundsYMax != null) trajBoundsYMax.interactable = interactable;
        }

        private void UpdateTrajectoryVisibility()
        {
            if (trajCurveType == null)
                return;

            bool isLine = trajCurveType.value == (int)TrajectoryCurveType.Line;
            bool isCircle = trajCurveType.value == (int)TrajectoryCurveType.Circle;
            bool isSpatialBounds = trajDomainMode.value == (int)TrajectoryDomainMode.SpatialBounds;

            if (radiusGroup != null) radiusGroup.SetActive(isCircle);
            if (rotationGroup != null) rotationGroup.SetActive(isLine);
            if (boundsGroup != null) boundsGroup.SetActive(isLine && isSpatialBounds);

            // SpatialBounds is Line-only
            if (isCircle && trajDomainMode.value == (int)TrajectoryDomainMode.SpatialBounds)
            {
                suppressTraj = true;
                trajDomainMode.value = (int)TrajectoryDomainMode.ParameterRange;
                suppressTraj = false;
            }
        }

        private void ApplyTrajectory()
        {
            if (suppressTraj || selectedPlatform == null || controller == null)
                return;

            TrajectoryData data = BuildTrajectoryDataFromUI();
            if (data == null)
                return;

            string error = Trajectory.Validate(data);
            if (trajValidation != null)
                trajValidation.text = error ?? "";

            controller.ApplySelectedTrajectoryFromUI(data);
            SetTrajectoryFieldsInteractable(data.enabled);
            UpdateTrajectoryVisibility();
        }

        private TrajectoryData BuildTrajectoryDataFromUI()
        {
            TrajectoryData data = new TrajectoryData();
            data.enabled = trajEnabled != null && trajEnabled.isOn;
            data.curveType = (TrajectoryCurveType)(trajCurveType != null ? trajCurveType.value : 0);
            data.domainMode = (TrajectoryDomainMode)(trajDomainMode != null ? trajDomainMode.value : 0);
            data.playbackMode = (TrajectoryPlaybackMode)(trajPlaybackMode != null ? trajPlaybackMode.value : 0);

            data.originX = TryParseField(trajOriginX, 0f);
            data.originY = TryParseField(trajOriginY, 0f);
            data.rotation = TryParseField(trajRotation, 0f);
            data.scaleX = TryParseField(trajScaleX, 5f);
            data.paramMin = TryParseField(trajParamMin, 0f);
            data.paramMax = TryParseField(trajParamMax, 1f);
            data.radius = TryParseField(trajRadius, 2f);
            data.duration = TryParseField(trajDuration, 4f);
            data.reverseDirection = trajReverse != null && trajReverse.isOn;

            data.boundsXMin = TryParseField(trajBoundsXMin, -10f);
            data.boundsXMax = TryParseField(trajBoundsXMax, 10f);
            data.boundsYMin = TryParseField(trajBoundsYMin, -10f);
            data.boundsYMax = TryParseField(trajBoundsYMax, 10f);

            return data;
        }

        private static float TryParseField(InputField field, float fallback)
        {
            if (field == null || string.IsNullOrEmpty(field.text))
                return fallback;
            return float.TryParse(field.text, out float v) ? v : fallback;
        }

        // ── UI creation helpers ────────────────────────────────────

        private void CreatePaletteButton(Transform parent, string label, LevelMarkerType type, bool marker, float y)
        {
            GameObject go = NewUI(label + "PaletteItem", parent);
            Image image = go.AddComponent<Image>();
            image.color = new UnityEngine.Color(0.85f, 0.85f, 0.85f, 1f);
            LevelEditorPaletteItem item = go.AddComponent<LevelEditorPaletteItem>();
            item.Initialize(controller, type, marker);

            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(1f, 1f);
            rt.anchorMax = new Vector2(1f, 1f);
            rt.pivot = new Vector2(1f, 1f);
            rt.sizeDelta = new Vector2(250f, 58f);
            rt.anchoredPosition = new Vector2(-35f, y);

            GameObject textGo = NewUI("Label", go.transform);
            Text text = textGo.AddComponent<Text>();
            text.font = GetFont();
            text.text = label;
            text.fontSize = 26;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = UnityEngine.Color.black;
            Stretch(textGo.GetComponent<RectTransform>());
        }

        private InputField CreateField(Transform parent, string label, float y)
        {
            CreateLabel(parent, label, new Vector2(22f, y), 22);
            GameObject go = NewUI(label + "Field", parent);
            Image image = go.AddComponent<Image>();
            image.color = UnityEngine.Color.white;
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.sizeDelta = new Vector2(170f, 42f);
            rt.anchoredPosition = new Vector2(155f, y + 9f);

            GameObject textGo = NewUI("Text", go.transform);
            Text text = textGo.AddComponent<Text>();
            text.font = GetFont();
            text.fontSize = 22;
            text.color = UnityEngine.Color.black;
            text.alignment = TextAnchor.MiddleLeft;
            Stretch(textGo.GetComponent<RectTransform>());

            InputField field = go.AddComponent<InputField>();
            field.textComponent = text;
            field.contentType = InputField.ContentType.DecimalNumber;
            return field;
        }

        private InputField CreateTrajField(Transform parent, string label, ref float y)
        {
            CreateLabel(parent, label, new Vector2(22f, y), 18);
            GameObject go = NewUI(label + "TrajField", parent);
            Image image = go.AddComponent<Image>();
            image.color = UnityEngine.Color.white;
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.sizeDelta = new Vector2(120f, 34f);
            rt.anchoredPosition = new Vector2(180f, y + 5f);

            GameObject textGo = NewUI("Text", go.transform);
            Text text = textGo.AddComponent<Text>();
            text.font = GetFont();
            text.fontSize = 18;
            text.color = UnityEngine.Color.black;
            text.alignment = TextAnchor.MiddleLeft;
            Stretch(textGo.GetComponent<RectTransform>());

            InputField field = go.AddComponent<InputField>();
            field.textComponent = text;
            field.contentType = InputField.ContentType.DecimalNumber;
            field.onEndEdit.AddListener(_ => ApplyTrajectory());
            return field;
        }

        private Toggle CreateToggle(Transform parent, string label, ref float y)
        {
            CreateLabel(parent, label, new Vector2(22f, y), 18);

            GameObject go = NewUI(label + "Toggle", parent);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.sizeDelta = new Vector2(30f, 30f);
            rt.anchoredPosition = new Vector2(180f, y + 2f);

            // Background
            GameObject bgGo = NewUI("Background", go.transform);
            Image bgImg = bgGo.AddComponent<Image>();
            bgImg.color = new UnityEngine.Color(0.3f, 0.3f, 0.3f, 1f);
            Stretch(bgGo.GetComponent<RectTransform>());

            // Checkmark
            GameObject checkGo = NewUI("Checkmark", bgGo.transform);
            Image checkImg = checkGo.AddComponent<Image>();
            checkImg.color = new UnityEngine.Color(0.2f, 0.9f, 0.2f, 1f);
            RectTransform checkRt = checkGo.GetComponent<RectTransform>();
            checkRt.anchorMin = new Vector2(0.15f, 0.15f);
            checkRt.anchorMax = new Vector2(0.85f, 0.85f);
            checkRt.offsetMin = Vector2.zero;
            checkRt.offsetMax = Vector2.zero;

            Toggle toggle = go.AddComponent<Toggle>();
            toggle.targetGraphic = bgImg;
            toggle.graphic = checkImg;
            toggle.isOn = false;

            return toggle;
        }

        private Dropdown CreateDropdown(Transform parent, string label, string[] options, ref float y)
        {
            CreateLabel(parent, label, new Vector2(22f, y), 18);

            GameObject go = NewUI(label + "Dropdown", parent);
            Image ddImg = go.AddComponent<Image>();
            ddImg.color = new UnityEngine.Color(0.9f, 0.9f, 0.9f, 1f);
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.sizeDelta = new Vector2(150f, 34f);
            rt.anchoredPosition = new Vector2(155f, y + 5f);

            // Caption text
            GameObject captionGo = NewUI("Label", go.transform);
            Text captionText = captionGo.AddComponent<Text>();
            captionText.font = GetFont();
            captionText.fontSize = 16;
            captionText.color = UnityEngine.Color.black;
            captionText.alignment = TextAnchor.MiddleLeft;
            Stretch(captionGo.GetComponent<RectTransform>());

            // Template
            GameObject template = NewUI("Template", go.transform);
            Image templateImg = template.AddComponent<Image>();
            templateImg.color = new UnityEngine.Color(0.95f, 0.95f, 0.95f, 1f);
            RectTransform templateRt = template.GetComponent<RectTransform>();
            templateRt.anchorMin = new Vector2(0f, 0f);
            templateRt.anchorMax = new Vector2(1f, 0f);
            templateRt.pivot = new Vector2(0.5f, 1f);
            templateRt.sizeDelta = new Vector2(0f, 120f);
            ScrollRect templateScroll = template.AddComponent<ScrollRect>();
            templateScroll.horizontal = false;

            // Viewport inside template
            GameObject templateViewport = NewUI("Viewport", template.transform);
            Image vpImg = templateViewport.AddComponent<Image>();
            vpImg.color = UnityEngine.Color.white;
            templateViewport.AddComponent<Mask>().showMaskGraphic = true;
            Stretch(templateViewport.GetComponent<RectTransform>());
            templateScroll.viewport = templateViewport.GetComponent<RectTransform>();

            // Content inside viewport
            GameObject templateContent = NewUI("Content", templateViewport.transform);
            RectTransform contentRt = templateContent.GetComponent<RectTransform>();
            contentRt.anchorMin = new Vector2(0f, 1f);
            contentRt.anchorMax = new Vector2(1f, 1f);
            contentRt.pivot = new Vector2(0.5f, 1f);
            contentRt.sizeDelta = new Vector2(0f, 28f);
            templateScroll.content = contentRt;

            // Item inside content
            GameObject item = NewUI("Item", templateContent.transform);
            RectTransform itemRt = item.GetComponent<RectTransform>();
            itemRt.anchorMin = new Vector2(0f, 0.5f);
            itemRt.anchorMax = new Vector2(1f, 0.5f);
            itemRt.sizeDelta = new Vector2(0f, 28f);
            Toggle itemToggle = item.AddComponent<Toggle>();

            // Item label
            GameObject itemLabelGo = NewUI("Item Label", item.transform);
            Text itemLabelText = itemLabelGo.AddComponent<Text>();
            itemLabelText.font = GetFont();
            itemLabelText.fontSize = 16;
            itemLabelText.color = UnityEngine.Color.black;
            itemLabelText.alignment = TextAnchor.MiddleLeft;
            Stretch(itemLabelGo.GetComponent<RectTransform>());

            template.SetActive(false);

            Dropdown dd = go.AddComponent<Dropdown>();
            dd.targetGraphic = ddImg;
            dd.captionText = captionText;
            dd.itemText = itemLabelText;
            dd.template = templateRt;

            dd.ClearOptions();
            var optList = new System.Collections.Generic.List<Dropdown.OptionData>();
            foreach (string opt in options)
                optList.Add(new Dropdown.OptionData(opt));
            dd.AddOptions(optList);

            return dd;
        }

        private Button CreateColoredButton(
            Transform parent, string label, Vector2 position, Vector2 size,
            UnityEngine.Color bgColor, UnityEngine.Events.UnityAction action)
        {
            GameObject go = NewUI(label + "Button", parent);
            Image img = go.AddComponent<Image>();
            img.color = bgColor;
            Button button = go.AddComponent<Button>();
            button.targetGraphic = img;
            button.onClick.AddListener(action);

            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.sizeDelta = size;
            rt.anchoredPosition = position;

            GameObject textGo = NewUI("Label", go.transform);
            Text text = textGo.AddComponent<Text>();
            text.font = GetFont();
            text.text = label;
            text.fontSize = 20;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = UnityEngine.Color.white;
            Stretch(textGo.GetComponent<RectTransform>());

            return button;
        }

        private void AddFieldCallback(InputField field)
        {
            field.onEndEdit.AddListener(_ => ApplyFields());
        }

        private void ApplyFields()
        {
            if (suppressFields || selectedPlatform == null || controller == null)
                return;

            if (!float.TryParse(posX.text, out float x) ||
                !float.TryParse(posY.text, out float y) ||
                !float.TryParse(sizeX.text, out float sx) ||
                !float.TryParse(sizeY.text, out float sy) ||
                !float.TryParse(color.text, out float raw))
                return;

            controller.ApplySelectedPlatformFromUI(
                new Vector2(x, y),
                new Vector2(Mathf.Max(0.1f, sx), Mathf.Max(0.1f, sy)),
                Mathf.Clamp(raw, 0f, 255f));
        }

        private static void CreateLabel(Transform parent, string textValue, Vector2 position, int fontSize, TextAnchor alignment = TextAnchor.MiddleLeft)
        {
            GameObject go = NewUI(textValue + "Label", parent);
            Text text = go.AddComponent<Text>();
            text.font = GetFont();
            text.text = textValue;
            text.fontSize = fontSize;
            text.alignment = alignment;
            text.color = UnityEngine.Color.white;
            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 1f);
            rt.anchorMax = new Vector2(0f, 1f);
            rt.pivot = new Vector2(0f, 1f);
            rt.sizeDelta = new Vector2(280f, fontSize + 10f);
            rt.anchoredPosition = position;
        }

        private static void CreateButton(Transform parent, string label, Vector2 position, UnityEngine.Events.UnityAction action)
        {
            GameObject go = NewUI(label + "Button", parent);
            Image img = go.AddComponent<Image>();
            img.color = new UnityEngine.Color(0.85f, 0.85f, 0.85f, 1f);
            Button button = go.AddComponent<Button>();
            button.targetGraphic = img;
            button.onClick.AddListener(action);

            RectTransform rt = go.GetComponent<RectTransform>();
            rt.anchorMin = new Vector2(0f, 0.5f);
            rt.anchorMax = new Vector2(0f, 0.5f);
            rt.pivot = new Vector2(0f, 0.5f);
            rt.sizeDelta = new Vector2(130f, 54f);
            rt.anchoredPosition = position;

            GameObject textGo = NewUI("Label", go.transform);
            Text text = textGo.AddComponent<Text>();
            text.font = GetFont();
            text.text = label;
            text.fontSize = 24;
            text.alignment = TextAnchor.MiddleCenter;
            text.color = UnityEngine.Color.black;
            Stretch(textGo.GetComponent<RectTransform>());
        }

        private static GameObject NewUI(string name, Transform parent)
        {
            GameObject go = new GameObject(name, typeof(RectTransform));
            go.transform.SetParent(parent, false);
            return go;
        }

        private static void Stretch(RectTransform rt)
        {
            rt.anchorMin = Vector2.zero;
            rt.anchorMax = Vector2.one;
            rt.offsetMin = Vector2.zero;
            rt.offsetMax = Vector2.zero;
        }

        private static Font GetFont()
        {
#if UNITY_2022_2_OR_NEWER
            return Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
#else
            return Resources.GetBuiltinResource<Font>("Arial.ttf");
#endif
        }

        private static void EnsureEventSystem()
        {
            if (FindAnyObjectByType<EventSystem>() != null)
                return;
            GameObject go = new GameObject("EventSystem");
            go.AddComponent<EventSystem>();
#if ENABLE_INPUT_SYSTEM
            go.AddComponent<UnityEngine.InputSystem.UI.InputSystemUIInputModule>();
#else
            go.AddComponent<StandaloneInputModule>();
#endif
        }
    }
}
