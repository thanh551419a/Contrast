using System;
using System.Collections.Generic;
using System.IO;
using Contrast.Data;
using Contrast.Player;
using Contrast.UI;
using UnityEngine;
using UnityEngine.EventSystems;
#if UNITY_EDITOR
using UnityEditor;
#endif
#if ENABLE_INPUT_SYSTEM
using UnityEngine.InputSystem;
#endif

namespace Contrast.Level
{
    /// <summary>
    /// Runtime level editor. It reuses LevelLoader's JSON schema and runtime
    /// construction. Editor interaction itself is independent from gameplay
    /// Physics2D and works directly against the same AABB/data used by gameplay.
    /// </summary>
    public sealed class LevelEditorController : MonoBehaviour
    {
        private enum SelectionKind
        {
            None,
            Platform,
            Marker
        }

        private enum HandleKind
        {
            None,
            Left,
            Right,
            Top,
            Bottom
        }

        [Header("Dependencies")]
        [SerializeField] private LevelLoader levelLoader;
        [SerializeField] private LevelEditorUI ui;

        [Header("Placement Defaults")]
        [SerializeField] private Vector2 defaultPlatformSize = Vector2.one;
        [SerializeField] private float defaultPlatformColor = 255f;
        [SerializeField] private Vector2 defaultMarkerSize = Vector2.one;
        [SerializeField] private float defaultMarkerColor = 0f;

        [Header("Editor Handles")]
        [SerializeField] private float handleSize = 0.16f;
        [SerializeField] private float handleHitRadius = 0.25f;

        [Header("Editor Debug")]
        [SerializeField] private bool logEditorInteraction = true;

        private bool editing;
        private bool paletteDragging;
        private bool mapPointerDragging;
        private bool mapPanning;
        private Vector2 panStartWorld;
        private Vector3 panStartCameraPosition;
        private LevelMarkerType pendingPaletteType;
        private bool pendingPaletteIsMarker;

        private SelectionKind selectionKind;
        private ColorPlatform selectedPlatform;
        private LevelMarker selectedMarker;
        private HandleKind activeHandle;

        private Vector2 dragStartWorld;
        private Vector2 dragStartPosition;
        private Vector2 dragStartSize;

        private GameObject handleRoot;
        private readonly Dictionary<HandleKind, GameObject> handles =
            new Dictionary<HandleKind, GameObject>();

        public bool IsEditing => editing;

        private void Awake()
        {
            levelLoader ??= FindAnyObjectByType<LevelLoader>();
            ui ??= FindAnyObjectByType<LevelEditorUI>(FindObjectsInactive.Include);
        }

        public void StartEditing()
        {
            editing = true;
            EnsureDependencies();
            EnsureHandleRoot();
            ClearSelection();
            ui?.Show(true);
        }

        public void StopEditing()
        {
            editing = false;
            paletteDragging = false;
            mapPointerDragging = false;
            mapPanning = false;
            activeHandle = HandleKind.None;
            ClearSelection();
            ui?.Show(false);
        }

        public void BeginPaletteDrag(LevelMarkerType type, bool marker)
        {
            if (!editing)
                return;

            pendingPaletteType = type;
            pendingPaletteIsMarker = marker;
            paletteDragging = true;
        }

        public void EndPaletteDrag(Vector2 screenPosition)
        {
            if (!paletteDragging)
                return;

            paletteDragging = false;

            if (IsPointerOverUi())
                return;

            Vector2 world = ScreenToWorld(screenPosition);
            CreateFromPalette(pendingPaletteType, pendingPaletteIsMarker, world);
        }

        public void RequestImport()
        {
#if UNITY_EDITOR
            string path = EditorUtility.OpenFilePanel(
                "Import Contrast Level",
                Application.dataPath,
                "json");

            if (!string.IsNullOrEmpty(path))
                ImportJson(path);
#else
            ui?.SetStatus(
                "Import trong build cần đường dẫn file trong StreamingAssets.");
#endif
        }

        public void ImportJson(string path)
        {
            if (!editing)
                return;

            if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
            {
                ui?.SetStatus("JSON file không tồn tại.");
                return;
            }

            try
            {
                string json = File.ReadAllText(path);
                LevelData data = JsonUtility.FromJson<LevelData>(json);

                if (data == null)
                {
                    ui?.SetStatus("Không thể đọc LevelData từ JSON.");
                    return;
                }

                if (!ValidateImportedData(data, out string error))
                {
                    ui?.SetStatus(error);
                    return;
                }

                EnsureDependencies();
                levelLoader.BuildRuntimeLevel(data);
                ClearSelection();
                ui?.SetStatus("Import level thành công.");
            }
            catch (Exception ex)
            {
                ui?.SetStatus("Import lỗi: " + ex.Message);
            }
        }

        public void RequestExport()
        {
            if (!editing)
                return;

            LevelData data = BuildExportData();
            string json = JsonUtility.ToJson(data, true);

#if UNITY_EDITOR
            string path = EditorUtility.SaveFilePanel(
                "Export Contrast Level",
                Application.dataPath,
                "ContrastLevel",
                "json");

            if (!string.IsNullOrEmpty(path))
            {
                File.WriteAllText(path, json);
                ui?.SetStatus("Export level thành công.");
            }
#else
            string path = Path.Combine(
                Application.persistentDataPath,
                "ContrastLevel.json");
            File.WriteAllText(path, json);
            ui?.SetStatus("Export: " + path);
#endif
        }

        public void SelectPlatform(ColorPlatform platform)
        {
            if (platform == null)
            {
                ClearSelection();
                return;
            }

            selectionKind = SelectionKind.Platform;
            selectedPlatform = platform;
            selectedMarker = null;
            activeHandle = HandleKind.None;
            ui?.SetSelectedPlatform(platform);
            RefreshHandles();
        }

        public void ApplySelectedPlatformFromUI(
            Vector2 position,
            Vector2 size,
            float rawColor)
        {
            if (selectedPlatform == null)
                return;

            selectedPlatform.SetEditorData(
                position,
                size,
                rawColor);

            RefreshHandles();
        }

        public void SelectMarker(LevelMarker marker)
        {
            if (marker == null)
            {
                ClearSelection();
                return;
            }

            selectionKind = SelectionKind.Marker;
            selectedMarker = marker;
            selectedPlatform = null;
            activeHandle = HandleKind.None;
            ui?.ClearSelectedPlatform();
            RefreshHandles();
        }

        private void Update()
        {
            if (!editing)
                return;

            Vector2 screenPosition = ScreenPointerPosition();
            bool pointerOverUi = IsPointerOverUi();

            // Middle mouse = pan the editor camera. Panning is independent from
            // platform selection/dragging and does not mutate level data.
            if (MiddlePointerDown())
            {
                if (!pointerOverUi)
                    BeginMapPan(screenPosition);
                else
                    LogEditor($"[EDITOR][PAN_BLOCKED_UI] screen={screenPosition}");
            }

            if (MiddlePointerHeld())
            {
                if (pointerOverUi)
                    CancelMapPan("Pointer entered UI while panning");
                else
                    ContinueMapPan(screenPosition);
            }

            if (MiddlePointerUp())
            {
                EndMapPan();
            }

            if (paletteDragging)
                return;

            if (PointerDown())
            {
                if (!pointerOverUi)
                    BeginMapPointer(screenPosition);
                else
                    LogEditor($"[EDITOR][MAP_POINTER_BLOCKED_UI] screen={screenPosition}");
            }

            if (PointerHeld() && mapPointerDragging)
            {
                // Once the user enters any UI element while dragging a platform,
                // cancel the map drag. Without this guard, InputField/panel focus
                // still leaves the left button pressed and the platform follows
                // the mouse over the UI.
                if (pointerOverUi)
                {
                    CancelMapPointerDrag("Pointer entered UI while dragging");
                }
                else
                {
                    ContinueMapPointer(screenPosition);
                }
            }

            if (PointerUp())
            {
                EndMapPointerDrag();
            }

            // Delete key shortcut — guarded so typing in an InputField
            // does not accidentally delete the selected platform.
            if (DeleteKeyPressed() && !IsInputFieldFocused())
            {
                DeleteSelectedPlatform();
            }

            RefreshHandles();
        }

        private void BeginMapPointer(Vector2 screenPosition)
        {
            Vector2 world = ScreenToWorld(screenPosition);

            HandleKind handle = HitHandle(world);
            if (handle != HandleKind.None && selectedPlatform != null)
            {
                mapPointerDragging = true;
                activeHandle = handle;
                dragStartWorld = world;
                dragStartPosition = selectedPlatform.Position;
                dragStartSize = selectedPlatform.Size;
                LogEditor($"[EDITOR][DRAG_START_HANDLE] platform={selectedPlatform.name} handle={activeHandle} world={world}");
                return;
            }

            ColorPlatform platform = HitPlatform(world);
            if (platform != null)
            {
                SelectPlatform(platform);
                mapPointerDragging = true;
                activeHandle = HandleKind.None;
                dragStartWorld = world;
                dragStartPosition = platform.Position;
                dragStartSize = platform.Size;
                LogEditor($"[EDITOR][DRAG_START_PLATFORM] platform={platform.name} world={world}");
                return;
            }

            LevelMarker marker = HitMarker(world);
            if (marker != null)
            {
                SelectMarker(marker);
                mapPointerDragging = true;
                activeHandle = HandleKind.None;
                dragStartWorld = world;
                dragStartPosition = marker.Position;
                dragStartSize = marker.Size;
                LogEditor($"[EDITOR][DRAG_START_MARKER] marker={marker.name} world={world}");
                return;
            }

            mapPointerDragging = false;
            ClearSelection();
        }

        private void ContinueMapPointer(Vector2 screenPosition)
        {
            if (selectionKind == SelectionKind.None)
                return;

            Vector2 world = ScreenToWorld(screenPosition);
            Vector2 delta = world - dragStartWorld;

            if (selectedPlatform != null &&
                selectionKind == SelectionKind.Platform)
            {
                if (activeHandle == HandleKind.None)
                {
                    selectedPlatform.SetEditorData(
                        dragStartPosition + delta,
                        dragStartSize,
                        selectedPlatform.RawGrayscaleColor);
                    ui?.RefreshSelectedPlatform(selectedPlatform);
                    return;
                }

                Vector2 size = dragStartSize;
                Vector2 position = dragStartPosition;

                switch (activeHandle)
                {
                    case HandleKind.Left:
                        size.x = Mathf.Max(0.1f, dragStartSize.x - delta.x);
                        position.x = dragStartPosition.x + delta.x * 0.5f;
                        break;

                    case HandleKind.Right:
                        size.x = Mathf.Max(0.1f, dragStartSize.x + delta.x);
                        position.x = dragStartPosition.x + delta.x * 0.5f;
                        break;

                    case HandleKind.Top:
                        size.y = Mathf.Max(0.1f, dragStartSize.y + delta.y);
                        position.y = dragStartPosition.y + delta.y * 0.5f;
                        break;

                    case HandleKind.Bottom:
                        size.y = Mathf.Max(0.1f, dragStartSize.y - delta.y);
                        position.y = dragStartPosition.y + delta.y * 0.5f;
                        break;
                }

                selectedPlatform.SetEditorData(
                    position,
                    size,
                    selectedPlatform.RawGrayscaleColor);

                ui?.RefreshSelectedPlatform(selectedPlatform);
                return;
            }

            if (selectedMarker != null &&
                selectionKind == SelectionKind.Marker &&
                activeHandle == HandleKind.None)
            {
                selectedMarker.SetEditorPosition(
                    dragStartPosition + delta);
            }
        }

        private void BeginMapPan(Vector2 screenPosition)
        {
            UnityEngine.Camera cam = UnityEngine.Camera.main;
            if (cam == null)
            {
                LogEditor("[EDITOR][PAN_START_FAILED] Camera.main = null");
                return;
            }

            mapPanning = true;
            panStartWorld = ScreenToWorld(screenPosition);
            panStartCameraPosition = cam.transform.position;
            LogEditor($"[EDITOR][PAN_START] screen={screenPosition} world={panStartWorld} camera={panStartCameraPosition}");
        }

        private void ContinueMapPan(Vector2 screenPosition)
        {
            if (!mapPanning)
                return;

            if (IsPointerOverUi())
                return;

            UnityEngine.Camera cam = UnityEngine.Camera.main;
            if (cam == null)
                return;

            Vector2 currentWorld = ScreenToWorld(screenPosition);
            Vector2 worldDelta = panStartWorld - currentWorld;
            Vector3 beforeCamera = cam.transform.position;

            cam.transform.position = new Vector3(
                beforeCamera.x + worldDelta.x,
                beforeCamera.y + worldDelta.y,
                beforeCamera.z);

            if (logEditorInteraction && Time.frameCount % 10 == 0)
            {
                LogEditor($"[EDITOR][PAN_MOVE] screen={screenPosition} delta={worldDelta} camera={cam.transform.position}");
            }
        }

        private void EndMapPan()
        {
            if (!mapPanning)
                return;

            mapPanning = false;
            UnityEngine.Camera cam = UnityEngine.Camera.main;
            LogEditor($"[EDITOR][PAN_END] camera={(cam != null ? cam.transform.position.ToString() : "null")}");
        }

        private void CancelMapPan(string reason)
        {
            if (!mapPanning)
                return;

            mapPanning = false;
            LogEditor($"[EDITOR][PAN_CANCEL] reason={reason}");
        }

        private void EndMapPointerDrag()
        {
            if (!mapPointerDragging)
                return;

            mapPointerDragging = false;
            activeHandle = HandleKind.None;
            LogEditor("[EDITOR][DRAG_END]");
        }

        private void CancelMapPointerDrag(string reason)
        {
            mapPointerDragging = false;
            activeHandle = HandleKind.None;
            LogEditor($"[EDITOR][DRAG_CANCEL] reason={reason}");
        }

        private void LogEditor(string message)
        {
            if (logEditorInteraction)
                Debug.Log(message);
        }

        private void CreateFromPalette(
            LevelMarkerType type,
            bool marker,
            Vector2 worldPosition)
        {
            if (marker)
            {
                if (type == LevelMarkerType.StartPos &&
                    HasMarker(LevelMarkerType.StartPos))
                {
                    ui?.SetStatus(
                        "ERROR: map chỉ được có 1 StartPos.");
                    return;
                }

                if (type == LevelMarkerType.End &&
                    HasMarker(LevelMarkerType.End))
                {
                    ui?.SetStatus(
                        "ERROR: map chỉ có 1 End theo JSON schema.");
                    return;
                }

                GameObject go = new GameObject(type.ToString());
                go.transform.SetParent(
                    FindOrCreateEditorRoot(),
                    false);

                LevelMarker markerComponent =
                    go.AddComponent<LevelMarker>();

                markerComponent.Initialize(
                    type,
                    worldPosition,
                    defaultMarkerSize,
                    type == LevelMarkerType.End
                        ? 255f
                        : defaultMarkerColor);

                SelectMarker(markerComponent);
                ui?.SetStatus(type + " added.");
                return;
            }

            GameObject platformObject =
                new GameObject("ColorPlatform_" + ColorPlatform.All.Count);

            platformObject.transform.SetParent(
                FindOrCreatePlatformRoot(),
                false);

            ColorPlatform platform =
                platformObject.AddComponent<ColorPlatform>();

            platform.Initialize(
                worldPosition,
                defaultPlatformSize,
                defaultPlatformColor);

            // Initialize a disabled trajectory for the new platform.
            platform.InitializeTrajectory(null);

            SelectPlatform(platform);
            ui?.SetStatus("Platform added.");
        }

        private bool ValidateImportedData(
            LevelData data,
            out string error)
        {
            error = null;

            // JsonUtility cannot represent duplicate singleton objects in a
            // useful way, so only platform null data is rejected here.
            if (data.platforms != null)
            {
                for (int i = 0; i < data.platforms.Length; i++)
                {
                    if (data.platforms[i] == null)
                    {
                        error = "JSON chứa platform null tại index " + i + ".";
                        return false;
                    }
                }
            }

            return true;
        }

        private LevelData BuildExportData()
        {
            LevelData source = levelLoader != null
                ? levelLoader.CurrentLevelData
                : null;

            LevelData data = source ?? new LevelData();

            // Filter out any null/destroyed entries that might remain.
            ColorPlatform.All.RemoveAll(p => p == null);

            data.platforms = new ColorPlatformData[
                ColorPlatform.All.Count];

            // Export the current schema only; do not keep a stale legacy spawnPoint.
            data.spawnPoint = null;

            for (int i = 0; i < ColorPlatform.All.Count; i++)
            {
                ColorPlatform p = ColorPlatform.All[i];

                // Use authored position for export (the pre-trajectory position).
                Vector2 exportPos = p.AuthoredPosition;

                // Build trajectory data for export. Never serialize runtime phase.
                TrajectoryData trajData = null;
                Trajectory traj = p.GetTrajectory();
                if (traj != null && traj.Config != null)
                    trajData = traj.Config.Clone();

                data.platforms[i] = new ColorPlatformData
                {
                    position = new Vector2Data(
                        exportPos.x,
                        exportPos.y),
                    size = new Vector2Data(
                        p.Size.x,
                        p.Size.y),
                    rawGrayscaleColor = p.RawGrayscaleColor,
                    trajectory = trajData
                };
            }

            data.startPos = null;
            data.checkPoint = null;
            data.end = null;

            List<CheckPointData> checkpoints =
                new List<CheckPointData>();

            for (int i = 0; i < LevelMarker.All.Count; i++)
            {
                LevelMarker marker = LevelMarker.All[i];
                if (marker == null)
                    continue;

                Vector2Data pos = new Vector2Data(
                    marker.Position.x,
                    marker.Position.y);
                Vector2Data size = new Vector2Data(
                    marker.Size.x,
                    marker.Size.y);

                switch (marker.Type)
                {
                    case LevelMarkerType.StartPos:
                        data.startPos = new StartPosData
                        {
                            position = pos,
                            size = size,
                            color = marker.RawColor
                        };
                        break;

                    case LevelMarkerType.CheckPoint:
                        checkpoints.Add(new CheckPointData
                        {
                            position = pos,
                            size = size,
                            color = marker.RawColor
                        });
                        break;

                    case LevelMarkerType.End:
                        data.end = new EndData
                        {
                            position = pos,
                            size = size
                        };
                        break;
                }
            }

            data.checkPoint = checkpoints.ToArray();

            return data;
        }

        private bool HasMarker(LevelMarkerType type)
        {
            for (int i = 0; i < LevelMarker.All.Count; i++)
            {
                LevelMarker marker = LevelMarker.All[i];
                if (marker != null && marker.Type == type && !marker.IsConsumed)
                    return true;
            }
            return false;
        }

        private ColorPlatform HitPlatform(Vector2 world)
        {
            for (int i = ColorPlatform.All.Count - 1; i >= 0; i--)
            {
                ColorPlatform platform = ColorPlatform.All[i];
                if (platform == null)
                    continue;

                Rect rect = platform.GetAabb();
                if (rect.Contains(world))
                    return platform;
            }

            return null;
        }

        private LevelMarker HitMarker(Vector2 world)
        {
            for (int i = LevelMarker.All.Count - 1; i >= 0; i--)
            {
                LevelMarker marker = LevelMarker.All[i];
                if (marker == null)
                    continue;

                Contrast.Player.Aabb bounds = marker.GetAabb();

                if (world.x >= bounds.Min.x &&
                    world.x <= bounds.Max.x &&
                    world.y >= bounds.Min.y &&
                    world.y <= bounds.Max.y)
                {
                    return marker;
                }
            }

            return null;
        }

        private HandleKind HitHandle(Vector2 world)
        {
            if (selectedPlatform == null)
                return HandleKind.None;

            Rect r = selectedPlatform.GetAabb();
            Vector2 left = new Vector2(r.xMin, r.center.y);
            Vector2 right = new Vector2(r.xMax, r.center.y);
            Vector2 top = new Vector2(r.center.x, r.yMax);
            Vector2 bottom = new Vector2(r.center.x, r.yMin);

            if (Vector2.Distance(world, left) <= handleHitRadius)
                return HandleKind.Left;
            if (Vector2.Distance(world, right) <= handleHitRadius)
                return HandleKind.Right;
            if (Vector2.Distance(world, top) <= handleHitRadius)
                return HandleKind.Top;
            if (Vector2.Distance(world, bottom) <= handleHitRadius)
                return HandleKind.Bottom;

            return HandleKind.None;
        }

        private void RefreshHandles()
        {
            EnsureHandleRoot();

            if (selectedPlatform == null || !editing)
            {
                SetHandlesVisible(false);
                return;
            }

            Rect r = selectedPlatform.GetAabb();
            SetHandle(HandleKind.Left, new Vector2(r.xMin, r.center.y));
            SetHandle(HandleKind.Right, new Vector2(r.xMax, r.center.y));
            SetHandle(HandleKind.Top, new Vector2(r.center.x, r.yMax));
            SetHandle(HandleKind.Bottom, new Vector2(r.center.x, r.yMin));
            SetHandlesVisible(true);
        }

        private void SetHandle(HandleKind kind, Vector2 position)
        {
            if (!handles.TryGetValue(kind, out GameObject go) || go == null)
                return;

            go.transform.position = new Vector3(
                position.x,
                position.y,
                -1f);

            go.transform.localScale =
                Vector3.one * handleSize;
        }

        private void SetHandlesVisible(bool visible)
        {
            foreach (GameObject go in handles.Values)
            {
                if (go != null)
                    go.SetActive(visible);
            }
        }

        private void EnsureHandleRoot()
        {
            if (handleRoot != null)
                return;

            handleRoot = new GameObject("EditorHandles");
            handleRoot.transform.SetParent(transform, false);

            CreateHandle(HandleKind.Left);
            CreateHandle(HandleKind.Right);
            CreateHandle(HandleKind.Top);
            CreateHandle(HandleKind.Bottom);
        }

        private void CreateHandle(HandleKind kind)
        {
            GameObject go = new GameObject(kind + "Handle");
            go.transform.SetParent(handleRoot.transform, false);

            SpriteRenderer sr = go.AddComponent<SpriteRenderer>();
            sr.sprite = ColorPlatform.GetDefaultSprite();
            sr.sortingOrder = 1000;
            sr.color = UnityEngine.Color.white;

            handles[kind] = go;
        }

        private void ClearSelection()
        {
            selectionKind = SelectionKind.None;
            selectedPlatform = null;
            selectedMarker = null;
            activeHandle = HandleKind.None;
            ui?.ClearSelectedPlatform();
            SetHandlesVisible(false);
        }

        /// <summary>
        /// Delete the currently selected platform. Safe to call when nothing
        /// is selected (no-op). Never deletes a LevelMarker.
        /// </summary>
        public void DeleteSelectedPlatform()
        {
            if (selectionKind != SelectionKind.Platform || selectedPlatform == null)
                return;

            ColorPlatform toDelete = selectedPlatform;
            string name = toDelete.name;

            // Clear selection first so UI references are cleaned up.
            ClearSelection();

            // Remove from registry (also handled by OnDestroy, but be explicit).
            ColorPlatform.All.Remove(toDelete);

            // Destroy the GameObject.
            Destroy(toDelete.gameObject);

            LogEditor($"[EDITOR][DELETE] platform={name}");
            ui?.SetStatus($"Deleted {name}.");
        }

        private Transform FindOrCreatePlatformRoot()
        {
            if (levelLoader != null)
            {
                Transform root = levelLoader.PlatformsRoot;
                if (root != null)
                    return root;
            }

            GameObject go = GameObject.Find("Platforms");
            if (go != null)
                return go.transform;

            return new GameObject("Platforms").transform;
        }

        private Transform FindOrCreateEditorRoot()
        {
            if (levelLoader != null)
            {
                Transform root = levelLoader.LevelObjectsRoot;
                if (root != null)
                    return root;
            }

            GameObject go = GameObject.Find("LevelObjects");
            if (go != null)
                return go.transform;

            return new GameObject("LevelObjects").transform;
        }

        private void EnsureDependencies()
        {
            levelLoader ??= FindAnyObjectByType<LevelLoader>();
            ui ??= FindAnyObjectByType<LevelEditorUI>(FindObjectsInactive.Include);
        }

        private static Vector2 ScreenToWorld(Vector2 screenPosition)
        {
            UnityEngine.Camera cam = UnityEngine.Camera.main;
            if (cam == null)
                return screenPosition;

            Vector3 screen = new Vector3(
                screenPosition.x,
                screenPosition.y,
                Mathf.Abs(cam.transform.position.z));

            Vector3 world = cam.ScreenToWorldPoint(screen);
            return new Vector2(world.x, world.y);
        }

        private static bool IsPointerOverUi()
        {
            return EventSystem.current != null &&
                   EventSystem.current.IsPointerOverGameObject();
        }

        private static Vector2 ScreenPointerPosition()
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null
                ? Mouse.current.position.ReadValue()
                : Vector2.zero;
#else
            return Input.mousePosition;
#endif
        }

        private static bool MiddlePointerDown()
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null &&
                   Mouse.current.middleButton.wasPressedThisFrame;
#else
            return Input.GetMouseButtonDown(2);
#endif
        }

        private static bool MiddlePointerHeld()
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null &&
                   Mouse.current.middleButton.isPressed;
#else
            return Input.GetMouseButton(2);
#endif
        }

        private static bool MiddlePointerUp()
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null &&
                   Mouse.current.middleButton.wasReleasedThisFrame;
#else
            return Input.GetMouseButtonUp(2);
#endif
        }

        private static bool PointerDown()
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null &&
                   Mouse.current.leftButton.wasPressedThisFrame;
#else
            return Input.GetMouseButtonDown(0);
#endif
        }

        private static bool PointerHeld()
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null &&
                   Mouse.current.leftButton.isPressed;
#else
            return Input.GetMouseButton(0);
#endif
        }

        private static bool PointerUp()
        {
#if ENABLE_INPUT_SYSTEM
            return Mouse.current != null &&
                   Mouse.current.leftButton.wasReleasedThisFrame;
#else
            return Input.GetMouseButtonUp(0);
#endif
        }

        private static bool DeleteKeyPressed()
        {
#if ENABLE_INPUT_SYSTEM
            Keyboard kb = Keyboard.current;
            return kb != null &&
                   (kb.deleteKey.wasPressedThisFrame || kb.backspaceKey.wasPressedThisFrame);
#else
            return Input.GetKeyDown(KeyCode.Delete) || Input.GetKeyDown(KeyCode.Backspace);
#endif
        }

        /// <summary>
        /// Returns true when a UI InputField currently has focus,
        /// preventing the Delete key from deleting a platform while
        /// the user is typing in a text field.
        /// </summary>
        private static bool IsInputFieldFocused()
        {
            if (EventSystem.current == null)
                return false;

            GameObject selected = EventSystem.current.currentSelectedGameObject;
            if (selected == null)
                return false;

            return selected.GetComponent<UnityEngine.UI.InputField>() != null;
        }

        /// <summary>
        /// Access the currently selected platform (if any).
        /// Used by LevelEditorUI for trajectory editing.
        /// </summary>
        public ColorPlatform SelectedPlatform => selectedPlatform;

        /// <summary>
        /// Apply trajectory configuration from the UI to the selected platform.
        /// </summary>
        public void ApplySelectedTrajectoryFromUI(TrajectoryData data)
        {
            if (selectedPlatform == null)
                return;

            Trajectory traj = selectedPlatform.GetTrajectory();
            if (traj == null)
            {
                selectedPlatform.InitializeTrajectory(data);
            }
            else
            {
                traj.SetConfig(data != null ? data.Clone() : null);
            }

            LogEditor($"[EDITOR][TRAJECTORY] platform={selectedPlatform.name} enabled={data?.enabled}");
        }
    }
}
