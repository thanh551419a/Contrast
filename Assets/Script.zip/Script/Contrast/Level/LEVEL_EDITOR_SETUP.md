# Contrast Runtime Level Editor

## Flow
- Main Menu -> PLAY GAME: loads the configured level JSON through LevelLoader.
- Main Menu -> EDIT LEVEL: opens the runtime editor.
- IMPORT: choose a JSON file in Unity Editor. The existing LevelLoader builds the map.
- EXPORT: serializes the current runtime platform and marker state back to JSON.

## Editor interaction
- Right palette: drag PLATFORM, START POS, CHECKPOINT or END into the map.
- Only one START POS and one END are allowed by the current JSON schema. Multiple CHECKPOINT entries are supported; export preserves all checkpoints.
- Click a platform to show four handles: left, right, top, bottom. Drag a handle to resize. Drag the platform body to move it.
- Markers can be dragged by body.
- Left panel shows and edits selected platform position, size and grayscale color. If the pointer enters an editor UI panel while a platform drag is active, the map drag is canceled so the platform cannot follow the UI cursor.
- Hold the middle mouse button over the map to pan the editor camera. Panning is editor-only and does not modify level object coordinates.

## Runtime build
- File import picker uses UnityEditor.OpenFilePanel when running inside the Unity Editor.
- Non-editor builds fall back to LevelEditorController.ImportJson(path), and export goes to Application.persistentDataPath.
